<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Join extends CI_Controller {

	function __construct(){
		parent:: __construct();
		$this->load->model(array('model_data'));
		
	}

	
	function index(){
		$data['dataUser']=$this->model_data->left_join();
		$this->load->view('welcome_message', $data);		

	}

	function right(){
		$data['dataR']=$this->model_data->right_join();
		$this->load->view('tampil_right', $data);		

	}
	
	function inner(){
		$data['dataI']=$this->model_data->inner_join();
		$this->load->view('tampil_inner', $data);		

	}
		
}
	

