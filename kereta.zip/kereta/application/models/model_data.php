<?php 

class Model_data extends CI_Model{
	function left_join(){
		$this->db->select('kursi.*, lokomotif.nama');
		$this->db->from('kursi');
		$this->db->join('lokomotif', 'kursi.kd_kereta = lokomotif.kd_kereta', 'left');
		$query = $this->db->get();
		return $query->result();
	}

	function right_join(){
		$this->db->select('kursi.*, gerbong.nama');
		$this->db->from('kursi');
		$this->db->join('gerbong', 'gerbong.kd_gerbong = kursi.kd_gerbong', 'right');
		$query = $this->db->get();
		return $query->result();
	}

	function inner_join(){
		$this->db->select('kursi.*, gerbong.nama_gerbong, lokomotif.nama');
		$this->db->from('kursi');
		$this->db->join('gerbong', 'gerbong.kd_gerbong = kursi.kd_gerbong', 'inner');
		$this->db->join('lokomotif', 'lokomotif.kd_kereta = kursi.kd_kereta', 'inner');
		$query = $this->db->get();
		return $query->result();
	}


	
}
