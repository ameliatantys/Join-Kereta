<!DOCTYPE html>
<html>
<head>
	<title>Kereta</title>
</head>
<body>
	<center></center>
	<table style="margin:20px auto;" border="1">
		<thead>
			<th>No</th>
			<th>Kode Kursi</th>
			<th>Kode Gerbong</th>
			<th>Nama Gerbong</th>
			<th>Kode Kereta</th>
			<th>Nama Kereta</th>
			
		</thead>
		<tbody>
			<?php
			$no=0;
			foreach ($dataI as $row ){
			$no++; ?>
				<tr>
					<td><?=$no?>
					<td><?=$row->kd_kursi?></td>
					<td><?=$row->kd_gerbong?></td>
					<td><?=$row->nama_gerbong?></td>
					<td><?=$row->kd_kereta?></td>
					<td><?=$row->nama?></td>
					
				</tr>

			<?php } ?>

			
		</tbody>
	</table>



</body>
</html>
