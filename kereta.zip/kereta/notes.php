Nama 	: Tanti Amelia Sopya
NIM		: 1701501
Jurusan	: Ilmu Komputer C-2017

i. Inner join
	IInner Join merupakan perintah untuk menampilkan semua data yang mempunyai nilai sama

ii. Left Join
Left Join merupakan cara menghubungkan tabel dan menampilkan semua data (kiri) pada tabel yang tidak berhubungan, sedangkan data yang kosong akan bernilai NULL.

iii.  Right Join
Fungsi ini hampir sama dengan fungsi Left Join ataupun kebalikannya, dimana Right Join akan menghubungkan tabel dan menampilkan semua data (kanan) pada tabel yang tidak berhubungan, dan data yang kosong akan bernilai NULL.


